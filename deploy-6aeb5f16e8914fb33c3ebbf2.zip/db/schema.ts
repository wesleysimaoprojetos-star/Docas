import { sql } from "drizzle-orm";
import { pgTable, serial, text, timestamp, jsonb, uniqueIndex, index } from "drizzle-orm/pg-core";

// Cada docagem/liberação de carreta
export const registros = pgTable(
  "registros",
  {
    id: serial().primaryKey(),
    carreta: text().notNull(),
    doca: text().notNull(),
    cavalo: text().notNull(),
    operador: text().notNull(),
    operacao: text().notNull(), // Carregar | Descarregar
    status: text().notNull().default("Em Doca"), // Em Doca | Liberada
    inicio: timestamp("inicio", { withTimezone: true }).notNull().defaultNow(),
    fim: timestamp("fim", { withTimezone: true }),
    operadorSaida: text("operador_saida"),
    fotoDocagem: text("foto_docagem"),
    fotoSaida: text("foto_saida"),
  },
  (t) => [
    // Garante no banco: uma doca só pode ter uma carreta ativa, e uma carreta só pode estar em uma doca
    uniqueIndex("registros_doca_ativa_uq").on(t.doca).where(sql`status = 'Em Doca'`),
    uniqueIndex("registros_carreta_ativa_uq").on(t.carreta).where(sql`status = 'Em Doca'`),
    index("registros_inicio_idx").on(t.inicio),
  ],
);

// Valores aprendidos para o preenchimento automático (carreta, doca, manobrista, cavalo)
export const cadastros = pgTable(
  "cadastros",
  {
    id: serial().primaryKey(),
    tipo: text().notNull(),
    valor: text().notNull(),
    criadoEm: timestamp("criado_em", { withTimezone: true }).notNull().defaultNow(),
    ultimoUso: timestamp("ultimo_uso", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("cadastros_tipo_valor_uq").on(t.tipo, t.valor)],
);

// Histórico de todas as ações realizadas no app
export const eventos = pgTable(
  "eventos",
  {
    id: serial().primaryKey(),
    acao: text().notNull(),
    descricao: text().notNull(),
    operador: text(),
    registroId: text("registro_id"),
    dados: jsonb(),
    ip: text(),
    dispositivo: text(),
    criadoEm: timestamp("criado_em", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("eventos_criado_em_idx").on(t.criadoEm)],
);
