CREATE TABLE "cadastros" (
	"id" serial PRIMARY KEY,
	"tipo" text NOT NULL,
	"valor" text NOT NULL,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL,
	"ultimo_uso" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "eventos" (
	"id" serial PRIMARY KEY,
	"acao" text NOT NULL,
	"descricao" text NOT NULL,
	"operador" text,
	"registro_id" text,
	"dados" jsonb,
	"ip" text,
	"dispositivo" text,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "registros" (
	"id" serial PRIMARY KEY,
	"carreta" text NOT NULL,
	"doca" text NOT NULL,
	"cavalo" text NOT NULL,
	"operador" text NOT NULL,
	"operacao" text NOT NULL,
	"status" text DEFAULT 'Em Doca' NOT NULL,
	"inicio" timestamp with time zone DEFAULT now() NOT NULL,
	"fim" timestamp with time zone,
	"operador_saida" text,
	"foto_docagem" text,
	"foto_saida" text
);
--> statement-breakpoint
CREATE UNIQUE INDEX "cadastros_tipo_valor_uq" ON "cadastros" ("tipo","valor");--> statement-breakpoint
CREATE INDEX "eventos_criado_em_idx" ON "eventos" ("criado_em");--> statement-breakpoint
CREATE UNIQUE INDEX "registros_doca_ativa_uq" ON "registros" ("doca") WHERE status = 'Em Doca';--> statement-breakpoint
CREATE UNIQUE INDEX "registros_carreta_ativa_uq" ON "registros" ("carreta") WHERE status = 'Em Doca';--> statement-breakpoint
CREATE INDEX "registros_inicio_idx" ON "registros" ("inicio");