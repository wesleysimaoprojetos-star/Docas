import type { Config, Context } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { cadastros, eventos, registros } from "../../db/schema.js";

const TIPOS = ["carreta", "doca", "manobrista", "cavalo"] as const;
type Tipo = (typeof TIPOS)[number];

const PADRAO: Record<Tipo, string[]> = {
  carreta: ["UOM5A64", "UQB4H35"],
  doca: ["01", "02", "03", "04", "05"],
  manobrista: ["Milson Moreira", "Maria Vieira"],
  cavalo: ["FRC3C97", "CRX3F42"],
};

const fotos = () => getStore({ name: "fotos-docagem", consistency: "strong" });

const json = (data: unknown, status = 200) =>
  Response.json(data, { status, headers: { "cache-control": "no-store" } });

const erro = (mensagem: string, status = 400) => json({ erro: mensagem }, status);

const placa = (v: unknown) => String(v ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10);
const doca = (v: unknown) => {
  const d = String(v ?? "").toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 10);
  return /^\d$/.test(d) ? "0" + d : d;
};
const nome = (v: unknown) => String(v ?? "").replace(/\s+/g, " ").trim().slice(0, 60);
const norm = (v: string) => v.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();

function limpar(tipo: Tipo, v: unknown) {
  if (tipo === "doca") return doca(v);
  if (tipo === "manobrista") return nome(v);
  return placa(v);
}

async function registrarEvento(
  req: Request,
  ctx: Context,
  acao: string,
  descricao: string,
  extra: { operador?: string; registroId?: number | string; dados?: unknown } = {},
) {
  try {
    await db.insert(eventos).values({
      acao,
      descricao,
      operador: extra.operador || null,
      registroId: extra.registroId != null ? String(extra.registroId) : null,
      dados: (extra.dados as object) ?? null,
      ip: ctx.ip || null,
      dispositivo: (req.headers.get("user-agent") || "").slice(0, 250) || null,
    });
  } catch (e) {
    console.error("Falha ao registrar evento", e);
  }
}

// Aprende (ou atualiza o último uso de) um valor para o preenchimento automático
async function aprender(tipo: Tipo, valor: string) {
  if (!valor) return valor;
  if (tipo === "manobrista") {
    const existentes = await db.select().from(cadastros).where(eq(cadastros.tipo, "manobrista"));
    const igual = existentes.find((c) => norm(c.valor) === norm(valor));
    if (igual) {
      await db.update(cadastros).set({ ultimoUso: new Date() }).where(eq(cadastros.id, igual.id));
      return igual.valor;
    }
  }
  await db
    .insert(cadastros)
    .values({ tipo, valor })
    .onConflictDoUpdate({ target: [cadastros.tipo, cadastros.valor], set: { ultimoUso: new Date() } });
  return valor;
}

async function garantirPadroes() {
  const [{ total }] = await db.select({ total: sql<number>`count(*)::int` }).from(cadastros);
  if (total > 0) return;
  const linhas = TIPOS.flatMap((tipo) => PADRAO[tipo].map((valor) => ({ tipo, valor })));
  await db.insert(cadastros).values(linhas).onConflictDoNothing();
}

async function salvarFoto(chave: string, dataUrl: unknown) {
  const m = /^data:image\/(jpeg|png|webp);base64,(.+)$/.exec(String(dataUrl || ""));
  if (!m) return null;
  const bytes = Buffer.from(m[2], "base64");
  if (bytes.length > 4_000_000) return null;
  await fotos().set(chave, new Blob([bytes], { type: `image/${m[1]}` }));
  return chave;
}

function serializar(r: typeof registros.$inferSelect) {
  return {
    id: r.id,
    carreta: r.carreta,
    doca: r.doca,
    cavalo: r.cavalo,
    operador: r.operador,
    operadorSaida: r.operadorSaida,
    operacao: r.operacao,
    status: r.status,
    inicioMs: r.inicio.getTime(),
    fimMs: r.fim ? r.fim.getTime() : null,
    fotoDocagem: r.fotoDocagem ? `/api/fotos/${r.fotoDocagem}` : null,
    fotoSaida: r.fotoSaida ? `/api/fotos/${r.fotoSaida}` : null,
  };
}

function ehViolacaoUnica(e: unknown) {
  const err = e as { code?: string; cause?: { code?: string } };
  return err?.code === "23505" || err?.cause?.code === "23505";
}

async function conflitoAtivo(carreta: string, docaV: string) {
  const ativos = await db.select().from(registros).where(eq(registros.status, "Em Doca"));
  const naDoca = ativos.find((r) => r.doca === docaV);
  if (naDoca) return `A doca ${docaV} está ocupada pela carreta ${naDoca.carreta}. Libere a doca antes de docar outra carreta.`;
  const daCarreta = ativos.find((r) => r.carreta === carreta);
  if (daCarreta)
    return `A carreta ${carreta} ainda está na doca ${daCarreta.doca} e não tem registro de saída. Libere a doca ${daCarreta.doca} primeiro.`;
  return null;
}

// ============================ ROTAS ============================

async function getEstado(url: URL) {
  await garantirPadroes();
  const dias = Math.min(365, Math.max(1, Number(url.searchParams.get("dias")) || 60));
  const desde = new Date(Date.now() - dias * 86400000);

  const [ativos, recentes, cads] = await Promise.all([
    db.select().from(registros).where(eq(registros.status, "Em Doca")).orderBy(desc(registros.inicio)),
    db
      .select()
      .from(registros)
      .where(and(eq(registros.status, "Liberada"), gte(registros.inicio, desde)))
      .orderBy(desc(registros.inicio))
      .limit(1000),
    db.select().from(cadastros).orderBy(desc(cadastros.ultimoUso)),
  ]);

  const lista: Record<Tipo, string[]> = { carreta: [], doca: [], manobrista: [], cavalo: [] };
  cads.forEach((c) => {
    if ((TIPOS as readonly string[]).includes(c.tipo)) lista[c.tipo as Tipo].push(c.valor);
  });

  return json({
    agora: Date.now(),
    registros: [...ativos, ...recentes].map(serializar),
    cadastros: lista,
  });
}

async function postDocar(req: Request, ctx: Context) {
  const body = await req.json().catch(() => ({}));
  const carreta = placa(body.carreta);
  const docaV = doca(body.doca);
  const cavalo = placa(body.cavalo);
  const operadorDigitado = nome(body.operador);
  const operacao = body.operacao === "Descarregar" ? "Descarregar" : "Carregar";

  if (!carreta) return erro("Informe a placa da carreta.");
  if (!docaV) return erro("Informe a doca.");
  if (!cavalo) return erro("Informe o cavalo de manobra.");
  if (!operadorDigitado) return erro("Informe o manobrista.");
  if (!body.foto) return erro("Tire a foto da carreta antes de docar.");

  const conflito = await conflitoAtivo(carreta, docaV);
  if (conflito) {
    await registrarEvento(req, ctx, "docagem_bloqueada", conflito, { operador: operadorDigitado, dados: { carreta, doca: docaV } });
    return erro(conflito, 409);
  }

  const operador = await aprender("manobrista", operadorDigitado);

  let novo;
  try {
    [novo] = await db
      .insert(registros)
      .values({ carreta, doca: docaV, cavalo, operador, operacao })
      .returning();
  } catch (e) {
    if (ehViolacaoUnica(e)) {
      const msg = (await conflitoAtivo(carreta, docaV)) || "Esta doca ou carreta acabou de ser registrada por outra pessoa.";
      await registrarEvento(req, ctx, "docagem_bloqueada", msg, { operador, dados: { carreta, doca: docaV } });
      return erro(msg, 409);
    }
    throw e;
  }

  const chave = await salvarFoto(`docagem-${novo.id}-${Date.now()}`, body.foto).catch((e) => {
    console.error("Falha ao salvar foto", e);
    return null;
  });
  if (chave) {
    [novo] = await db.update(registros).set({ fotoDocagem: chave }).where(eq(registros.id, novo.id)).returning();
  }

  await Promise.all([aprender("carreta", carreta), aprender("doca", docaV), aprender("cavalo", cavalo)]);
  await registrarEvento(
    req,
    ctx,
    "docagem",
    `Carreta ${carreta} docada na doca ${docaV} para ${operacao.toLowerCase()} (cavalo ${cavalo})`,
    { operador, registroId: novo.id, dados: { carreta, doca: docaV, cavalo, operacao, foto: !!chave } },
  );

  return json({ registro: serializar(novo) }, 201);
}

async function postLiberar(req: Request, ctx: Context) {
  const body = await req.json().catch(() => ({}));
  const id = Number(body.id);
  const operador = nome(body.operador);
  if (!id) return erro("Registro inválido.");
  if (!body.foto) return erro("Tire a foto da liberação.");

  const [atual] = await db.select().from(registros).where(eq(registros.id, id));
  if (!atual) return erro("Registro não encontrado.", 404);
  if (atual.status !== "Em Doca") return erro(`A carreta ${atual.carreta} já foi liberada por outra pessoa.`, 409);

  const chave = await salvarFoto(`saida-${id}-${Date.now()}`, body.foto).catch(() => null);
  if (!chave) return erro("Não foi possível salvar a foto da liberação. Tente novamente.", 500);

  const [reg] = await db
    .update(registros)
    .set({ status: "Liberada", fim: new Date(), fotoSaida: chave, operadorSaida: operador || null })
    .where(and(eq(registros.id, id), eq(registros.status, "Em Doca")))
    .returning();
  if (!reg) return erro(`A carreta ${atual.carreta} já foi liberada por outra pessoa.`, 409);

  if (operador) await aprender("manobrista", operador);
  const min = Math.round(((reg.fim?.getTime() || Date.now()) - reg.inicio.getTime()) / 60000);
  await registrarEvento(req, ctx, "liberacao", `Doca ${reg.doca} liberada · carreta ${reg.carreta} (${min} min em doca)`, {
    operador: operador || undefined,
    registroId: reg.id,
    dados: { carreta: reg.carreta, doca: reg.doca, minutos: min },
  });

  return json({ registro: serializar(reg) });
}

async function postCadastro(req: Request, ctx: Context) {
  const body = await req.json().catch(() => ({}));
  const tipo = body.tipo as Tipo;
  if (!TIPOS.includes(tipo)) return erro("Tipo inválido.");
  const valor = limpar(tipo, body.valor);
  if (!valor) return erro("Valor inválido.");

  const existentes = await db.select().from(cadastros).where(eq(cadastros.tipo, tipo));
  if (existentes.some((c) => norm(c.valor) === norm(valor))) return erro("Já está cadastrado.", 409);

  await db.insert(cadastros).values({ tipo, valor }).onConflictDoNothing();
  await registrarEvento(req, ctx, "cadastro", `Cadastro de ${tipo} adicionado: ${valor}`, {
    operador: nome(body.operador) || undefined,
    dados: { tipo, valor },
  });
  return json({ ok: true }, 201);
}

async function deleteCadastro(req: Request, ctx: Context) {
  const body = await req.json().catch(() => ({}));
  const tipo = body.tipo as Tipo;
  if (!TIPOS.includes(tipo)) return erro("Tipo inválido.");
  const valor = String(body.valor || "");
  const apagados = await db
    .delete(cadastros)
    .where(and(eq(cadastros.tipo, tipo), eq(cadastros.valor, valor)))
    .returning();
  if (apagados.length) {
    await registrarEvento(req, ctx, "cadastro_removido", `Cadastro de ${tipo} removido: ${valor}`, {
      operador: nome(body.operador) || undefined,
      dados: { tipo, valor },
    });
  }
  return json({ ok: true });
}

async function getEventos(url: URL) {
  const limite = Math.min(2000, Math.max(1, Number(url.searchParams.get("limite")) || 300));
  const lista = await db.select().from(eventos).orderBy(desc(eventos.criadoEm)).limit(limite);
  return json({
    eventos: lista.map((e) => ({
      id: e.id,
      acao: e.acao,
      descricao: e.descricao,
      operador: e.operador,
      registroId: e.registroId,
      ip: e.ip,
      dispositivo: e.dispositivo,
      quandoMs: e.criadoEm.getTime(),
    })),
  });
}

async function getFoto(chave: string) {
  if (!/^[a-z]+-\d+-\d+$/.test(chave)) return new Response("Not found", { status: 404 });
  const blob = await fotos().get(chave, { type: "blob" });
  if (!blob) return new Response("Not found", { status: 404 });
  return new Response(blob, {
    headers: {
      "content-type": blob.type || "image/jpeg",
      "cache-control": "private, max-age=31536000, immutable",
    },
  });
}

async function postEvento(req: Request, ctx: Context) {
  // Ações registradas pelo navegador (ex.: envio de evidência no WhatsApp, exportação da planilha)
  const body = await req.json().catch(() => ({}));
  const permitidas = ["whatsapp", "exportacao", "acesso"];
  const acao = String(body.acao || "");
  if (!permitidas.includes(acao)) return erro("Ação inválida.");
  await registrarEvento(req, ctx, acao, String(body.descricao || acao).slice(0, 300), {
    operador: nome(body.operador) || undefined,
    registroId: body.registroId,
  });
  return json({ ok: true }, 201);
}

export default async (req: Request, ctx: Context) => {
  const url = new URL(req.url);
  const rota = url.pathname.replace(/^\/api\/?/, "").replace(/\/$/, "");
  try {
    if (req.method === "GET" && rota === "estado") return await getEstado(url);
    if (req.method === "GET" && rota === "eventos") return await getEventos(url);
    if (req.method === "GET" && rota.startsWith("fotos/")) return await getFoto(rota.slice(6));
    if (req.method === "POST" && rota === "docar") return await postDocar(req, ctx);
    if (req.method === "POST" && rota === "liberar") return await postLiberar(req, ctx);
    if (req.method === "POST" && rota === "cadastros") return await postCadastro(req, ctx);
    if (req.method === "DELETE" && rota === "cadastros") return await deleteCadastro(req, ctx);
    if (req.method === "POST" && rota === "eventos") return await postEvento(req, ctx);
    return erro("Rota não encontrada.", 404);
  } catch (e) {
    console.error(e);
    return erro("Erro no servidor. Tente novamente.", 500);
  }
};

export const config: Config = {
  path: "/api/*",
};
