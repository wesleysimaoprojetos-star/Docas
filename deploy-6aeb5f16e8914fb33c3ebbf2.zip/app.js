// =====================================================================
// LEMAR · Controle de Docagem — dados compartilhados entre todos os usuários
// =====================================================================
const TIPOS = ["carreta", "doca", "cavalo", "manobrista"];
const NOMES_TIPO = { carreta: "Carreta", doca: "Doca", cavalo: "Cavalo de Manobra", manobrista: "Manobrista" };
const PREFS_KEY = "lemar_doca_prefs_v3";

const estado = {
  registros: [],
  cadastros: { carreta: [], doca: [], cavalo: [], manobrista: [] },
  eventos: [],
  carregado: false,
  offsetRelogio: 0, // diferença entre o relógio do servidor e o do aparelho
};

let prefs = {};
try { prefs = JSON.parse(localStorage.getItem(PREFS_KEY) || "{}") || {}; } catch (e) { prefs = {}; }
function salvarPrefs() { try { localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); } catch (e) {} }

let fotoDocagemPronta = null;
let fotoSaidaPronta = null;
let idEmLiberacao = null;
let fotoEntradaImg = null;
let fotoEntradaHora = null;
let enviando = false;

const $ = (id) => document.getElementById(id);
const agoraMs = () => Date.now() + estado.offsetRelogio;

function esc(v) {
  return String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function normalizar(v) {
  return String(v || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();
}
function formatarPlaca(v) {
  return String(v || "").toUpperCase().replace(/[^A-Z0-9]/g, "").trim();
}
function formatarDocaValor(v) {
  const d = String(v || "").toUpperCase().replace(/[^A-Z0-9-]/g, "").trim();
  return /^\d$/.test(d) ? "0" + d : d;
}
function formatarValor(tipo, v) {
  if (tipo === "doca") return formatarDocaValor(v);
  if (tipo === "manobrista") return String(v || "").replace(/\s+/g, " ").trim();
  return formatarPlaca(v);
}
function ordenarDocas(lista) {
  return [...lista].sort((a, b) => {
    const na = parseInt(a, 10), nb = parseInt(b, 10);
    if (!isNaN(na) && !isNaN(nb) && na !== nb) return na - nb;
    return String(a).localeCompare(String(b), "pt-BR", { numeric: true });
  });
}
function dataHoraStr(ms) {
  if (!ms) return "";
  const d = new Date(ms);
  return `${d.toLocaleDateString("pt-BR")} às ${d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`;
}
function calcularTempo(inicioMs, fimMs) {
  const fim = fimMs || agoraMs();
  const diffMin = Math.max(0, Math.floor((fim - inicioMs) / 60000));
  const h = Math.floor(diffMin / 60);
  const m = diffMin % 60;
  return h === 0 ? `${m}min` : `${h}h ${m}min`;
}

let toastTimer = null;
function toast(msg, erro) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast" + (erro ? " erro" : "");
  t.style.display = "block";
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.style.display = "none"), erro ? 6000 : 3500);
}

// ========================================================
// COMUNICAÇÃO COM O SERVIDOR
// ========================================================
async function api(caminho, opcoes = {}) {
  const resp = await fetch("/api/" + caminho, {
    ...opcoes,
    headers: { "content-type": "application/json", ...(opcoes.headers || {}) },
  });
  let dados = null;
  try { dados = await resp.json(); } catch (e) {}
  if (!resp.ok) {
    const err = new Error((dados && dados.erro) || "Falha de conexão. Verifique a internet e tente novamente.");
    err.status = resp.status;
    throw err;
  }
  return dados;
}

function definirSync(ok, txt) {
  const el = $("sync");
  el.className = "sync " + (ok ? "on" : "off");
  $("sync-txt").textContent = txt;
}

let sincronizando = false;
async function sincronizar() {
  if (sincronizando) return;
  sincronizando = true;
  try {
    const dados = await api("estado");
    estado.offsetRelogio = dados.agora - Date.now();
    estado.registros = dados.registros;
    estado.cadastros = dados.cadastros;
    estado.carregado = true;
    definirSync(true, "Conectado · atualizado " + new Date().toLocaleTimeString("pt-BR"));
    renderizarTudo();
  } catch (e) {
    definirSync(false, "Sem conexão · tentando novamente...");
  } finally {
    sincronizando = false;
  }
}

async function carregarHistorico() {
  try {
    const dados = await api("eventos?limite=500");
    estado.eventos = dados.eventos;
    renderizarHistorico();
  } catch (e) {}
}

function registrarAcaoCliente(acao, descricao, registroId) {
  api("eventos", {
    method: "POST",
    body: JSON.stringify({ acao, descricao, registroId, operador: $("man-operador").value.trim() || prefs.operador || "" }),
  }).catch(() => {});
}

// ========================================================
// CONSULTAS
// ========================================================
const registrosAtivos = () => estado.registros.filter((r) => r.status === "Em Doca");
const ativoDaCarreta = (placa) => registrosAtivos().find((r) => r.carreta === placa);
const ativoDaDoca = (doca) => registrosAtivos().find((r) => r.doca === doca);
const ultimoRegistroDaCarreta = (placa) => estado.registros.find((r) => r.carreta === placa);
const buscarRegistro = (id) => estado.registros.find((r) => r.id === id);

// ========================================================
// PREENCHIMENTO AUTOMÁTICO (SEM MENU SUSPENSO)
// Mostra uma única sugestão logo abaixo do campo, baseada no que já foi usado no app.
// Toque na sugestão (ou Tab / Enter / → no computador) para completar.
// ========================================================
function candidatos(tipo) {
  let lista = estado.cadastros[tipo] || []; // já vem ordenada pelo uso mais recente
  if (tipo === "carreta") lista = lista.filter((c) => !ativoDaCarreta(c));
  if (tipo === "doca") lista = lista.filter((d) => !ativoDaDoca(d));
  return lista;
}

function melhorSugestao(tipo, texto) {
  const q = normalizar(texto);
  if (!q) return null;
  const lista = candidatos(tipo);
  if (lista.some((v) => normalizar(v) === q)) return null; // já está completo
  const qPlaca = tipo === "manobrista" ? q : normalizar(formatarValor(tipo, texto));
  return (
    lista.find((v) => normalizar(v).startsWith(qPlaca)) ||
    lista.find((v) => normalizar(v).includes(qPlaca)) ||
    null
  );
}

function botaoSugestao(input) {
  return input.parentElement.querySelector(".sugestao");
}

function atualizarSugestao(input) {
  const btn = botaoSugestao(input);
  const tipo = input.dataset.tipo;
  const sug = document.activeElement === input || input.value ? melhorSugestao(tipo, input.value) : null;
  if (!sug) { btn.hidden = true; btn.dataset.valor = ""; return; }
  let detalhe = "";
  if (tipo === "carreta") {
    const ult = ultimoRegistroDaCarreta(sug);
    if (ult) detalhe = `última: doca ${ult.doca}`;
  }
  btn.dataset.valor = sug;
  btn.innerHTML = `↳ ${esc(sug)} <small>${detalhe ? esc(detalhe) + " · " : ""}toque para completar</small>`;
  btn.hidden = false;
}

function aceitarSugestao(input) {
  const btn = botaoSugestao(input);
  if (btn.hidden || !btn.dataset.valor) return false;
  input.value = btn.dataset.valor;
  btn.hidden = true;
  input.dispatchEvent(new Event("change"));
  return true;
}

function ligarPreenchimento(input) {
  const btn = botaoSugestao(input);
  btn.addEventListener("pointerdown", (e) => e.preventDefault()); // não tira o foco do campo
  btn.addEventListener("click", () => { aceitarSugestao(input); focarProximo(input); });
  input.addEventListener("input", () => atualizarSugestao(input));
  input.addEventListener("focus", () => atualizarSugestao(input));
  input.addEventListener("blur", () => setTimeout(() => atualizarSugestao(input), 150));
  input.addEventListener("keydown", (e) => {
    const noFim = input.selectionStart === input.value.length;
    if ((e.key === "Tab" && !e.shiftKey) || e.key === "Enter" || (e.key === "ArrowRight" && noFim)) {
      if (aceitarSugestao(input) && e.key !== "Tab") e.preventDefault();
      else if (e.key === "Enter") { e.preventDefault(); focarProximo(input); }
    }
  });
}

function focarProximo(input) {
  const ordem = ["man-cavalo", "man-carreta", "man-doca", "man-operador"];
  const i = ordem.indexOf(input.id);
  const prox = ordem.slice(i + 1).map((id) => $(id)).find((el) => !el.value);
  if (prox) prox.focus(); else input.blur();
}

// ========================================================
// VALIDAÇÃO / BLOQUEIOS
// ========================================================
function verificarBloqueio() {
  const placa = formatarPlaca($("man-carreta").value);
  const doca = formatarDocaValor($("man-doca").value);
  if (placa) {
    const ativo = ativoDaCarreta(placa);
    if (ativo) return `A carreta ${placa} já está na doca ${ativo.doca} desde ${dataHoraStr(ativo.inicioMs)} e ainda não tem registro de saída. Libere a doca ${ativo.doca} antes de docar de novo.`;
  }
  if (doca) {
    const ocupante = ativoDaDoca(doca);
    if (ocupante) return `A doca ${doca} está ocupada pela carreta ${ocupante.carreta}. Só é possível docar quando ela for liberada.`;
  }
  return null;
}

function atualizarAjudasFormulario() {
  const cInp = $("man-carreta"), dInp = $("man-doca");
  const placa = formatarPlaca(cInp.value);
  const doca = formatarDocaValor(dInp.value);
  const dicaC = $("dica-carreta"), dicaD = $("dica-doca");

  dicaC.className = "dica-campo"; dicaC.textContent = "";
  cInp.classList.remove("campo-bloqueado");
  if (placa) {
    const ativo = ativoDaCarreta(placa);
    const ult = ultimoRegistroDaCarreta(placa);
    if (ativo) {
      dicaC.className = "dica-campo alerta";
      dicaC.textContent = `⛔ Já está na doca ${ativo.doca} — sem registro de saída`;
      cInp.classList.add("campo-bloqueado");
    } else if (ult) {
      dicaC.textContent = `Última vez: doca ${ult.doca} (${ult.operacao})`;
    } else if (!(estado.cadastros.carreta || []).includes(placa) && placa.length >= 7) {
      dicaC.textContent = "Nova carreta — será cadastrada automaticamente.";
    }
  }

  dicaD.className = "dica-campo"; dicaD.textContent = "";
  dInp.classList.remove("campo-bloqueado");
  if (doca) {
    const ocupante = ativoDaDoca(doca);
    if (ocupante) {
      dicaD.className = "dica-campo alerta";
      dicaD.textContent = `⛔ Ocupada pela carreta ${ocupante.carreta}`;
      dInp.classList.add("campo-bloqueado");
    } else if ((estado.cadastros.doca || []).includes(doca)) {
      dicaD.className = "dica-campo ok";
      dicaD.textContent = "✓ Doca livre";
    } else if (estado.carregado) {
      dicaD.textContent = "Nova doca — será cadastrada automaticamente.";
    }
  }

  const bloqueio = verificarBloqueio();
  const aviso = $("aviso-bloqueio");
  aviso.textContent = bloqueio ? "⛔ " + bloqueio : "";
  aviso.classList.toggle("ativo", !!bloqueio);
  $("btn-docar-carregar").disabled = !!bloqueio || enviando;
  $("btn-docar-descarregar").disabled = !!bloqueio || enviando;

  ["man-cavalo", "man-carreta", "man-doca", "man-operador"].forEach((id) => atualizarSugestao($(id)));
}

// ========================================================
// NAVEGAÇÃO
// ========================================================
let subAbaAtual = "sub-planilha";
function abrirGerenciarCadastros() {
  $("tela-manobra").classList.remove("active");
  $("tela-gerenciar").classList.add("active");
  trocarSubAba("sub-planilha");
  window.scrollTo(0, 0);
}
function voltarManobra() {
  $("tela-gerenciar").classList.remove("active");
  $("tela-manobra").classList.add("active");
  window.scrollTo(0, 0);
}
function trocarSubAba(id) {
  subAbaAtual = id;
  document.querySelectorAll(".sub-tela").forEach((el) => (el.style.display = el.id === id ? "block" : "none"));
  document.querySelectorAll(".sub-btn").forEach((b) => b.classList.toggle("active", b.dataset.sub === id));
  if (id === "sub-historico") carregarHistorico();
}

// ========================================================
// CADASTROS (compartilhados)
// ========================================================
function montarTelasCadastro() {
  $("cadastros-box").innerHTML = TIPOS.map((tipo) => `
    <div id="sub-${tipo}" class="sub-tela sub-cadastro" style="display:none;">
      <div class="card">
        <div class="card-title">Cadastrar ${NOMES_TIPO[tipo]}</div>
        <form onsubmit="cadastrarManual(event, '${tipo}')" class="form-inline" autocomplete="off">
          <input type="text" id="novo-${tipo}" ${tipo === "manobrista" ? 'autocapitalize="words"' : 'class="uppercase-input" autocapitalize="characters"'}
            placeholder="${tipo === "manobrista" ? "Nome do manobrista" : tipo === "doca" ? "Número da doca" : "Placa"}" required autocomplete="off" autocorrect="off" spellcheck="false">
          <button type="submit" class="btn btn-carregar" style="width:auto; margin:0; padding:0 1.2rem;">Adicionar</button>
        </form>
      </div>
      <div class="card">
        <div class="card-title">${NOMES_TIPO[tipo]}s cadastrad${tipo === "doca" ? "a" : "o"}s</div>
        <div id="lista-${tipo}-base"></div>
      </div>
    </div>`).join("");
}

async function cadastrarManual(e, tipo) {
  e.preventDefault();
  const inp = $("novo-" + tipo);
  const valor = formatarValor(tipo, inp.value);
  if (!valor) return toast("Valor inválido.", true);
  try {
    await api("cadastros", { method: "POST", body: JSON.stringify({ tipo, valor, operador: prefs.operador || "" }) });
    inp.value = "";
    toast(`${NOMES_TIPO[tipo]} ${valor} cadastrado.`);
    sincronizar();
  } catch (err) {
    toast(err.message, true);
  }
}

async function removerCadastro(tipo, valor) {
  if (!confirm(`Remover ${NOMES_TIPO[tipo].toLowerCase()} ${valor} dos cadastros?`)) return;
  try {
    await api("cadastros", { method: "DELETE", body: JSON.stringify({ tipo, valor, operador: prefs.operador || "" }) });
    sincronizar();
  } catch (err) {
    toast(err.message, true);
  }
}

function renderizarCadastros() {
  TIPOS.forEach((tipo) => {
    const box = $(`lista-${tipo}-base`);
    if (!box) return;
    let lista = estado.cadastros[tipo] || [];
    if (tipo === "doca") lista = ordenarDocas(lista);
    if (lista.length === 0) { box.innerHTML = '<p style="font-size:0.85rem; color:var(--muted);">Nenhum cadastro.</p>'; return; }
    box.innerHTML = lista.map((v) => {
      const extra = tipo === "doca" && ativoDaDoca(v) ? ` <small style="color:var(--danger);">· ocupada (${esc(ativoDaDoca(v).carreta)})</small>`
        : tipo === "carreta" && ativoDaCarreta(v) ? ` <small style="color:var(--lemar-yellow);">· na doca ${esc(ativoDaCarreta(v).doca)}</small>` : "";
      return `<div class="tag-item"><span>${esc(v)}${extra}</span>
        <button type="button" class="btn-del-tag" data-tipo="${tipo}" data-valor="${esc(v)}" onclick="removerCadastro(this.dataset.tipo, this.dataset.valor)" aria-label="Remover">✕</button></div>`;
    }).join("");
  });
}

// ========================================================
// FOTO COM CARIMBO
// ========================================================
function carimbarImagem(img, docaTxt, placaTxt, dataHora, prefixo) {
  const canvas = $("canvas-carimbo");
  const ctx = canvas.getContext("2d");
  const maxDim = 1000;
  let w = img.naturalWidth || img.width;
  let h = img.naturalHeight || img.height;
  const escala = Math.min(1, maxDim / Math.max(w, h));
  w = Math.round(w * escala);
  h = Math.round(h * escala);
  canvas.width = w;
  canvas.height = h;
  ctx.drawImage(img, 0, 0, w, h);

  const f1 = Math.max(15, Math.round(w * 0.024));
  const f2 = Math.max(12, Math.round(w * 0.019));
  const barH = Math.round(f1 + f2 + f1 * 1.6);
  ctx.fillStyle = "rgba(0, 0, 0, 0.88)";
  ctx.fillRect(0, h - barH, w, barH);
  ctx.fillStyle = "#ffb800";
  ctx.fillRect(0, h - barH, w, 3);
  ctx.fillStyle = "#ffb800";
  ctx.font = `bold ${f1}px sans-serif`;
  ctx.fillText(`${prefixo ? prefixo + " · " : ""}DOCA: ${docaTxt}`, 14, h - barH + f1 + 6);
  ctx.fillStyle = "#ffffff";
  ctx.font = `bold ${f2}px sans-serif`;
  ctx.fillText(`PLACA DA CARRETA: ${placaTxt} : ${dataHora}`, 14, h - barH + f1 + f2 + 14, w - 28);
  return canvas.toDataURL("image/jpeg", 0.7);
}
function dataHoraCarimbo(d) {
  return d.toLocaleDateString("pt-BR") + ", " + d.toLocaleTimeString("pt-BR");
}
function recarimbarEntrada() {
  if (!fotoEntradaImg) return;
  const carreta = formatarPlaca($("man-carreta").value) || "CARRETA";
  const doca = formatarDocaValor($("man-doca").value) || "--";
  fotoDocagemPronta = carimbarImagem(fotoEntradaImg, doca, carreta, dataHoraCarimbo(fotoEntradaHora), "");
  $("preview-entrada").src = fotoDocagemPronta;
}

function processarFotoChecklist(event, tipo) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  const st = $(tipo === "entrada" ? "status-foto-entrada" : "status-foto-saida");
  st.style.display = "block";
  st.innerText = "⚡ Carimbando foto...";
  const reader = new FileReader();
  reader.onerror = () => (st.innerText = "❌ Não foi possível ler a foto. Tente novamente.");
  reader.onload = (e) => {
    const img = new Image();
    img.onerror = () => (st.innerText = "❌ Formato de foto não suportado. Tire a foto novamente.");
    img.onload = () => {
      const agora = new Date(agoraMs());
      if (tipo === "entrada") {
        fotoEntradaImg = img;
        fotoEntradaHora = agora;
        recarimbarEntrada();
        $("preview-entrada").style.display = "block";
        st.innerText = "✅ Foto pronta com carimbo!";
      } else {
        const reg = buscarRegistro(idEmLiberacao);
        fotoSaidaPronta = carimbarImagem(img, reg ? reg.doca : "--", reg ? reg.carreta : "CARRETA", dataHoraCarimbo(agora), "LIBERAÇÃO");
        const prev = $("preview-saida");
        prev.src = fotoSaidaPronta;
        prev.style.display = "block";
        st.innerText = "✅ Foto pronta!";
        $("btn-concluir-liberacao").style.display = "flex";
      }
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

// ========================================================
// WHATSAPP (GRUPO MELI)
// ========================================================
function dataURLtoFile(dataurl, filename) {
  const arr = dataurl.split(",");
  const mime = arr[0].match(/:(.*?);/)[1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) u8arr[n] = bstr.charCodeAt(n);
  return new File([u8arr], filename, { type: mime });
}

async function obterArquivoFoto(foto, nome) {
  if (!foto) return null;
  if (foto.startsWith("data:")) return dataURLtoFile(foto, nome);
  const resp = await fetch(foto);
  if (!resp.ok) return null;
  const blob = await resp.blob();
  return new File([blob], nome, { type: blob.type || "image/jpeg" });
}

let whatsPendente = null;

async function compartilharEvidenciaWhatsApp(textoMsg, arquivoFoto, registroId) {
  if (arquivoFoto && navigator.canShare) {
    try {
      if (navigator.canShare({ files: [arquivoFoto] })) {
        await navigator.share({ files: [arquivoFoto], text: textoMsg, title: "Evidência de Docagem - LEMAR" });
        registrarAcaoCliente("whatsapp", "Evidência compartilhada no WhatsApp", registroId);
        return;
      }
    } catch (err) {
      if (err && err.name === "AbortError") return;
      if (err && err.name === "NotAllowedError") {
        // O navegador exige um novo toque: mostra o botão de envio
        whatsPendente = { textoMsg, arquivoFoto, registroId };
        $("modal-whats-info").textContent = "Toque no botão abaixo para enviar a evidência no grupo do WhatsApp.";
        $("modal-whats").style.display = "flex";
        return;
      }
      console.warn("Compartilhamento nativo não suportado:", err);
    }
  }

  if (arquivoFoto) {
    const url = URL.createObjectURL(arquivoFoto);
    const a = document.createElement("a");
    a.href = url;
    a.download = arquivoFoto.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  const textoEncoded = encodeURIComponent(textoMsg);
  const ehMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) || (navigator.maxTouchPoints > 1 && /Macintosh/.test(navigator.userAgent));
  if (ehMobile) {
    const link = document.createElement("a");
    link.href = "whatsapp://send?text=" + textoEncoded;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  setTimeout(() => {
    if (!document.hidden) {
      const dominioWa = ["https://", "api.", "whatsapp", ".com", "/send?text="].join("");
      window.open(dominioWa + textoEncoded, "_blank");
    }
  }, ehMobile ? 1200 : 0);
  registrarAcaoCliente("whatsapp", "Evidência enviada para o WhatsApp", registroId);
}

function enviarWhatsPendente() {
  const p = whatsPendente;
  fecharModalWhats();
  if (p) compartilharEvidenciaWhatsApp(p.textoMsg, p.arquivoFoto, p.registroId);
}
function fecharModalWhats() {
  $("modal-whats").style.display = "none";
  whatsPendente = null;
}

function montarMensagem(reg) {
  return `*LEMAR TRANSPORTES - OPERAÇÃO EMBU DROP&HOOK* 🚛📦
---------------------------------------
*Carreta:* ${reg.carreta}
*Doca:* ${reg.doca}
*Operação:* DOCAGEM P/ ${String(reg.operacao).toUpperCase()}
*Cavalo de Manobra:* ${reg.cavalo}
*Horário:* ${dataHoraStr(reg.inicioMs)}
*Manobrista:* ${reg.operador}
*Status:* Posicionada em doca (Operação Meli)
---------------------------------------`;
}

// ========================================================
// DOCAGEM
// ========================================================
async function confirmarDocagem(tipoOperacao, botao) {
  if (enviando) return;
  const cInp = $("man-carreta"), dInp = $("man-doca"), oInp = $("man-operador"), cvInp = $("man-cavalo");
  const carreta = formatarPlaca(cInp.value);
  const doca = formatarDocaValor(dInp.value);
  const cavalo = formatarPlaca(cvInp.value);
  const opDigitado = oInp.value.replace(/\s+/g, " ").trim();
  const operador = (estado.cadastros.manobrista || []).find((m) => normalizar(m) === normalizar(opDigitado)) || opDigitado;

  if (!cavalo) return toast("Informe o cavalo de manobra.", true);
  if (!carreta) return toast("Informe a placa da carreta.", true);
  if (!doca) return toast("Informe a doca.", true);
  if (!operador) return toast("Informe o manobrista.", true);
  if (!fotoDocagemPronta) return toast("Tire a foto da carreta antes de docar.", true);

  const bloqueio = verificarBloqueio();
  if (bloqueio) { atualizarAjudasFormulario(); return toast(bloqueio, true); }

  dInp.value = doca;
  cInp.value = carreta;
  recarimbarEntrada();

  const fotoParaEnvio = fotoDocagemPronta;
  const textoOriginal = botao.innerHTML;
  enviando = true;
  botao.innerHTML = "⏳ Registrando...";
  atualizarAjudasFormulario();

  try {
    const { registro } = await api("docar", {
      method: "POST",
      body: JSON.stringify({ carreta, doca, cavalo, operador, operacao: tipoOperacao, foto: fotoParaEnvio }),
    });

    prefs.cavalo = cavalo;
    prefs.operador = operador;
    salvarPrefs();
    oInp.value = operador;

    cInp.value = "";
    dInp.value = "";
    $("preview-entrada").style.display = "none";
    $("status-foto-entrada").style.display = "none";
    $("foto-entrada").value = "";
    fotoDocagemPronta = null;
    fotoEntradaImg = null;
    fotoEntradaHora = null;

    estado.registros = [registro, ...estado.registros.filter((r) => r.id !== registro.id)];
    renderizarTudo();
    sincronizar();

    const arquivo = dataURLtoFile(fotoParaEnvio, `Docagem_${registro.carreta}_Doca${registro.doca}.jpg`);
    compartilharEvidenciaWhatsApp(montarMensagem(registro), arquivo, registro.id);
  } catch (err) {
    toast(err.message, true);
    if (err.status === 409) sincronizar();
  } finally {
    enviando = false;
    botao.innerHTML = textoOriginal;
    atualizarAjudasFormulario();
  }
}

async function reenviarWhatsRegistro(id) {
  const reg = buscarRegistro(id);
  if (!reg) return;
  let arquivo = null;
  try { arquivo = await obterArquivoFoto(reg.fotoDocagem, `Docagem_${reg.carreta}_Doca${reg.doca}.jpg`); } catch (e) {}
  compartilharEvidenciaWhatsApp(montarMensagem(reg), arquivo, reg.id);
}

// ========================================================
// MODAIS
// ========================================================
function abrirModalFoto(id, tipoFoto) {
  const reg = buscarRegistro(id);
  if (!reg) return;
  const foto = tipoFoto === "saida" ? reg.fotoSaida : reg.fotoDocagem;
  if (!foto) return toast("Foto não disponível.", true);
  $("modal-foto-titulo").innerText = `Evidência: ${reg.carreta}`;
  $("modal-foto-img").src = foto;
  $("modal-foto-info").innerHTML = `
    <strong>Doca:</strong> ${esc(reg.doca)} | <strong>Operação:</strong> Docada p/ ${esc(reg.operacao)}<br>
    <strong>Horário Docagem:</strong> ${esc(dataHoraStr(reg.inicioMs))}<br>
    ${reg.fimMs ? `<strong>Horário Saída:</strong> ${esc(dataHoraStr(reg.fimMs))}<br>` : ""}
    <strong>Manobrista:</strong> ${esc(reg.operador)}${reg.operadorSaida ? ` · <strong>Liberado por:</strong> ${esc(reg.operadorSaida)}` : ""}`;
  $("modal-ver-foto").style.display = "flex";
  document.body.style.overflow = "hidden";
}
function fecharModalFoto() {
  $("modal-ver-foto").style.display = "none";
  document.body.style.overflow = "";
}

function abrirModalLiberar(id) {
  const reg = buscarRegistro(id);
  if (!reg) return;
  idEmLiberacao = id;
  fotoSaidaPronta = null;
  $("preview-saida").style.display = "none";
  $("btn-concluir-liberacao").style.display = "none";
  $("status-foto-saida").style.display = "none";
  $("foto-saida").value = "";
  $("modal-info-carreta").innerText = `Carreta: ${reg.carreta} | Doca: ${reg.doca} (${reg.operacao}) | Início: ${dataHoraStr(reg.inicioMs)}`;
  $("modal-liberar").style.display = "flex";
  document.body.style.overflow = "hidden";
}
function fecharModalLiberar() {
  $("modal-liberar").style.display = "none";
  document.body.style.overflow = "";
  idEmLiberacao = null;
}

async function concluirLiberacao(botao) {
  if (!fotoSaidaPronta || !idEmLiberacao || botao.disabled) return;
  const id = idEmLiberacao;
  const textoOriginal = botao.innerHTML;
  botao.disabled = true;
  botao.innerHTML = "⏳ Registrando liberação...";
  try {
    const operador = $("man-operador").value.trim() || prefs.operador || "";
    const { registro } = await api("liberar", { method: "POST", body: JSON.stringify({ id, foto: fotoSaidaPronta, operador }) });
    estado.registros = estado.registros.map((r) => (r.id === registro.id ? registro : r));
    fecharModalLiberar();
    renderizarTudo();
    toast(`Carreta ${registro.carreta} liberada! Doca ${registro.doca} disponível.`);
    sincronizar();
  } catch (err) {
    toast(err.message, true);
    if (err.status === 409) { fecharModalLiberar(); sincronizar(); }
  } finally {
    botao.disabled = false;
    botao.innerHTML = textoOriginal;
  }
}

// ========================================================
// RENDERIZAÇÃO
// ========================================================
function renderizarListas() {
  const box = $("lista-ativas");
  const ativas = registrosAtivos();
  $("contador-ativas").textContent = estado.carregado ? `${ativas.length} ocupada${ativas.length === 1 ? "" : "s"}` : "";
  if (!estado.carregado) return;
  if (ativas.length === 0) {
    box.innerHTML = '<p style="font-size:0.85rem; color:var(--muted); text-align:center; padding:0.8rem;">Nenhuma carreta em doca no momento.</p>';
    return;
  }
  box.innerHTML = ativas.map((r) => `
    <div class="item-doca ${r.operacao === "Descarregar" ? "descarregar" : ""}">
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.35rem;">
        <div>
          <button type="button" class="btn-placa-foto" onclick="abrirModalFoto(${r.id}, 'doca')" title="Toque para ver a foto">🚛 ${esc(r.carreta)}</button>
          <span style="font-size:0.75rem; color:var(--muted); margin-left:4px;">(Cavalo: ${esc(r.cavalo)})</span>
        </div>
        <div style="display:flex; gap:0.35rem; align-items:center;">
          <span class="badge-tipo ${r.operacao === "Carregar" ? "badge-carregar" : "badge-descarregar"}">${r.operacao === "Carregar" ? "Carregamento" : "Descarregamento"}</span>
          <span style="background:var(--lemar-yellow); color:#000; padding:0.2rem 0.5rem; border-radius:4px; font-weight:800; font-size:0.78rem;">${esc(r.doca)}</span>
        </div>
      </div>
      <div style="font-size:0.8rem; color:#9ca3af; margin:0.35rem 0;">
        Docada em: <strong>${esc(dataHoraStr(r.inicioMs))}</strong> · Manobrista: ${esc(r.operador)}
      </div>
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.4rem;">
        <span style="color:var(--lemar-yellow); font-weight:700; font-size:0.88rem;">⏱️ ${calcularTempo(r.inicioMs)} em doca</span>
        <div class="item-acoes">
          <button type="button" class="btn btn-whats-item" onclick="reenviarWhatsRegistro(${r.id})" title="Compartilhar Evidência no WhatsApp">📲 WhatsApp</button>
          <button type="button" class="btn btn-liberar" onclick="abrirModalLiberar(${r.id})">Liberar Doca</button>
        </div>
      </div>
    </div>`).join("");
}

function registrosFiltrados() {
  const q = normalizar($("filtro-planilha").value);
  if (!q) return estado.registros;
  return estado.registros.filter((r) => [r.carreta, r.doca, r.operador, r.operadorSaida, r.cavalo].some((v) => normalizar(v).includes(q)));
}

function renderizarPlanilhaExcel() {
  const tbody = document.querySelector("#tbl-relatorio tbody");
  const lista = registrosFiltrados();
  if (lista.length === 0) {
    tbody.innerHTML = '<tr><td colspan="12" style="text-align:center; color:var(--muted); padding:1rem;">Nenhum registro encontrado.</td></tr>';
    return;
  }
  tbody.innerHTML = lista.map((r) => `
    <tr>
      <td><span class="badge-status ${r.status === "Em Doca" ? "em-doca" : "liberada"}">${esc(r.status)}</span></td>
      <td><strong>${esc(r.carreta)}</strong></td>
      <td>${esc(r.doca)}</td>
      <td><span class="badge-tipo ${r.operacao === "Carregar" ? "badge-carregar" : "badge-descarregar"}">${esc(r.operacao)}</span></td>
      <td>${esc(dataHoraStr(r.inicioMs))}</td>
      <td>${r.fotoDocagem ? `<button type="button" class="btn-link-foto" onclick="abrirModalFoto(${r.id}, 'doca')">📷 Foto</button>` : "-"}</td>
      <td>${esc(dataHoraStr(r.fimMs)) || "-"}</td>
      <td>${r.fotoSaida ? `<button type="button" class="btn-link-foto" onclick="abrirModalFoto(${r.id}, 'saida')">📷 Foto</button>` : "-"}</td>
      <td><strong>${calcularTempo(r.inicioMs, r.fimMs)}</strong>${r.fimMs ? "" : " <small style='color:var(--muted)'>(em andamento)</small>"}</td>
      <td>${esc(r.cavalo)}</td>
      <td>${esc(r.operador)}</td>
      <td>${esc(r.operadorSaida || "-")}</td>
    </tr>`).join("");
}

const NOMES_ACAO = {
  docagem: "Docagem",
  liberacao: "Liberação",
  docagem_bloqueada: "Docagem bloqueada",
  cadastro: "Cadastro",
  cadastro_removido: "Cadastro removido",
  whatsapp: "WhatsApp",
  exportacao: "Exportação",
  acesso: "Acesso",
};

function resumoDispositivo(ua) {
  ua = ua || "";
  const so = /Android/i.test(ua) ? "Android" : /iPhone|iPad|iPod/i.test(ua) ? "iPhone/iPad" : /Windows/i.test(ua) ? "Windows" : /Mac/i.test(ua) ? "Mac" : /Linux/i.test(ua) ? "Linux" : "—";
  const nav = /Edg\//.test(ua) ? "Edge" : /Chrome\//.test(ua) ? "Chrome" : /Firefox\//.test(ua) ? "Firefox" : /Safari\//.test(ua) ? "Safari" : "";
  return nav ? `${so} · ${nav}` : so;
}

function renderizarHistorico() {
  const tbody = document.querySelector("#tbl-historico tbody");
  if (estado.eventos.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--muted); padding:1rem;">Nenhuma ação registrada ainda.</td></tr>';
    return;
  }
  tbody.innerHTML = estado.eventos.map((e) => `
    <tr>
      <td>${esc(new Date(e.quandoMs).toLocaleString("pt-BR"))}</td>
      <td><strong>${esc(NOMES_ACAO[e.acao] || e.acao)}</strong></td>
      <td style="white-space:normal; min-width:240px;">${esc(e.descricao)}</td>
      <td>${esc(e.operador || "-")}</td>
      <td>${esc(resumoDispositivo(e.dispositivo))}</td>
    </tr>`).join("");
}

function renderizarTudo() {
  renderizarListas();
  renderizarCadastros();
  renderizarPlanilhaExcel();
  atualizarAjudasFormulario();
}

// ========================================================
// EXPORTAÇÃO CSV
// ========================================================
function baixarCsv(nome, linhas) {
  const q = (v) => `"${String(v == null ? "" : v).replace(/"/g, '""')}"`;
  const csv = "﻿" + linhas.map((l) => l.map(q).join(";")).join("\n") + "\n";
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = nome;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function baixarPlanilhaExcel() {
  const lista = registrosFiltrados();
  if (lista.length === 0) return toast("Não há registros para exportar.", true);
  const base = location.origin;
  const linhas = [["Status", "Placa Carreta", "Doca", "Operação", "Data/Hora Docagem", "Data/Hora Saída", "Tempo em Doca (min)", "Tempo em Doca", "Cavalo Manobra", "Manobrista", "Liberado por", "Foto Docagem", "Foto Saída"]];
  lista.forEach((r) => {
    const min = Math.max(0, Math.floor(((r.fimMs || agoraMs()) - r.inicioMs) / 60000));
    linhas.push([r.status, r.carreta, r.doca, r.operacao, dataHoraStr(r.inicioMs), dataHoraStr(r.fimMs), min, calcularTempo(r.inicioMs, r.fimMs), r.cavalo, r.operador, r.operadorSaida || "", r.fotoDocagem ? base + r.fotoDocagem : "", r.fotoSaida ? base + r.fotoSaida : ""]);
  });
  baixarCsv(`Relatorio_Docas_Lemar_${new Date().toISOString().slice(0, 10)}.csv`, linhas);
  registrarAcaoCliente("exportacao", `Planilha de docas exportada (${lista.length} registros)`);
}

function baixarHistoricoCsv() {
  if (estado.eventos.length === 0) return toast("Não há ações para exportar.", true);
  const linhas = [["Data/Hora", "Ação", "Descrição", "Manobrista", "Dispositivo", "IP"]];
  estado.eventos.forEach((e) => linhas.push([new Date(e.quandoMs).toLocaleString("pt-BR"), NOMES_ACAO[e.acao] || e.acao, e.descricao, e.operador || "", resumoDispositivo(e.dispositivo), e.ip || ""]));
  baixarCsv(`Historico_Acoes_Lemar_${new Date().toISOString().slice(0, 10)}.csv`, linhas);
  registrarAcaoCliente("exportacao", `Histórico de ações exportado (${estado.eventos.length} linhas)`);
}

// ========================================================
// INICIALIZAÇÃO
// ========================================================
(function iniciar() {
  montarTelasCadastro();

  const cInp = $("man-carreta"), dInp = $("man-doca"), oInp = $("man-operador"), cvInp = $("man-cavalo");
  [cInp, dInp, cvInp].forEach((inp) => inp.addEventListener("input", () => {
    const pos = inp.selectionStart;
    inp.value = inp.value.toUpperCase();
    try { inp.setSelectionRange(pos, pos); } catch (e) {}
  }));
  [cInp, dInp].forEach((inp) => {
    inp.addEventListener("input", atualizarAjudasFormulario);
    inp.addEventListener("change", () => { atualizarAjudasFormulario(); recarimbarEntrada(); });
  });
  dInp.addEventListener("blur", () => {
    const f = formatarDocaValor(dInp.value);
    if (f !== dInp.value) { dInp.value = f; atualizarAjudasFormulario(); recarimbarEntrada(); }
  });
  cInp.addEventListener("blur", () => {
    const f = formatarPlaca(cInp.value);
    if (f !== cInp.value) { cInp.value = f; atualizarAjudasFormulario(); recarimbarEntrada(); }
  });
  oInp.addEventListener("change", () => { prefs.operador = oInp.value.trim(); salvarPrefs(); });
  cvInp.addEventListener("change", () => { prefs.cavalo = formatarPlaca(cvInp.value); salvarPrefs(); });

  [cvInp, cInp, dInp, oInp].forEach(ligarPreenchimento);

  // Último cavalo e manobrista usados neste aparelho já vêm preenchidos
  if (prefs.cavalo) cvInp.value = prefs.cavalo;
  if (prefs.operador) oInp.value = prefs.operador;

  $("modal-ver-foto").addEventListener("click", (e) => { if (e.target.id === "modal-ver-foto") fecharModalFoto(); });
  $("modal-liberar").addEventListener("click", (e) => { if (e.target.id === "modal-liberar") fecharModalLiberar(); });
  $("modal-whats").addEventListener("click", (e) => { if (e.target.id === "modal-whats") fecharModalWhats(); });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { fecharModalFoto(); fecharModalWhats(); if (idEmLiberacao) fecharModalLiberar(); }
  });

  const atualizarRelogio = () => {
    $("relogio-topo").innerText = new Date(agoraMs()).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  };

  // Sincroniza com os outros usuários a cada 5 segundos enquanto o app estiver aberto
  setInterval(() => { if (!document.hidden) sincronizar(); }, 5000);
  setInterval(() => { atualizarRelogio(); renderizarListas(); }, 30000);
  setInterval(() => { if (!document.hidden && subAbaAtual === "sub-historico" && $("tela-gerenciar").classList.contains("active")) carregarHistorico(); }, 15000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { atualizarRelogio(); sincronizar(); } });
  window.addEventListener("online", sincronizar);

  atualizarRelogio();
  renderizarTudo();
  sincronizar();
})();
